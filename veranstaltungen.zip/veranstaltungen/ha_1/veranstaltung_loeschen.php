<?php
require_once 'functions.php';
require_once 'functions_veranstaltungen.php';


include TEMPLATES . 'veranstaltung_loeschen.phtml';
