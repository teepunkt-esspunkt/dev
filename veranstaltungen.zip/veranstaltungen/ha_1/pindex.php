<?php
require_once 'functions.php';

include TEMPLATES . 'tabellephp.phtml';