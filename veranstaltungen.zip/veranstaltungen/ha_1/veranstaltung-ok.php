<?php
require_once 'functions.php';

include TEMPLATES . 'veranstaltung-ok.phtml';