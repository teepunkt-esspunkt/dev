<?php
require_once 'functions.php';
$ausgabe['titel'] = 'Gelöscht!';
include TEMPLATES . 'htmlkopf.phtml';
?>

            <h3><a href="pindex.php">Liste anzeigen</a></h3>
     <?php
include TEMPLATES . 'htmlfuss.phtml';