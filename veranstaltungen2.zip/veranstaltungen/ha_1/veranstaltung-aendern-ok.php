<?php
require_once 'functions.php';

include TEMPLATES . 'veranstaltung-aendern-ok.phtml';