<?php 
$anrede = [
    '1' => "Herr",
    '2' => "Frau",
    '3' => "Firma",
];

$zusatz = [
    '1' => "WLAN",
    '2' => "Sauna",
    '3' => "Fitnessraum",   
];

$verpflegung = [
    '1' => "Frühstück",
    '2' => "Halbpension",
    '3' => "Vollpension",
];

$hotelkategorie = [
    '1' => "Standard",
    '2' => "Comfort",
    '3' => "Premium",
];