<?php 
  require_once 'init.php';
require_once 'funktionen_strings.php';
 
// Array für die Adressen
$adressen = [];


$datei = fopen('buchung.csv', 'r');

// Adressen aus der Datei lesen
while($adresse = fgetcsv($datei)) {
    
        
    //$adresse[0] = $titel[$adressen][0];
$adressen[] = $adresse;
}

// Datei schließen
fclose($datei);

$zaehler = 0;

$form['suche']         = $_GET['suche'] ?? '0';

?>
<!DOCTYPE html>
<html lang="de">
    <head>
        <title>Adressausgabe</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="styles.css" rel="stylesheet">
    </head>
    <body>
        <div id="wrapper">
            <nav id="top">
                <ul>
                    <li><a href = "">Home</a></li>
                </ul>
                <ul>
                    <li><a href = "">Kontakt |</a></li>
                    <li><a href = "">Impressum</a></li>
                </ul>
            </nav>
            <main>
                <nav id="left">
                    <ul>
                        <?php meineLinkeNavBarLeiste(); ?>
                    </ul>
                </nav>
        
                <article>
                    <h1> Adressliste </h1>
                    <table>
                        <caption> Adressen </caption>
                        <colgroup>
                        <?php 
                        for($i = 0; $i <= count($adressen); $i++):
                        ?>
                            <col>
                          
                        <?php
                        endfor;
                        ?>
                        </colgroup>
                      
                        <?php
                        
                        $i = 0;
                        foreach($adressen as  $key => $value):
                        ?>
                            <tr>
                                <?php
                                echo "<th>" . $zaehler . "</th>";
                                $zaehler++;
                                
                                foreach($adressen[$key] as $key2 => $value2):
                                    
                                ?>
                                        <td><?= $value2 ?></td>

                                        <?php 
                                       
                                endforeach;
                                ?>
                            </tr>
                        <?php    
                        endforeach;
                        ?>
                    </table>
                            <div>
                                <label for="suche">Suchfeld</label>
                                <input type="text" name="suche" id="suche"><br>
                                <span class="suche"></span><br>
<!--                                Ich habe mich zu lange mit der CSS aufgehalten, da die Fieldsets mein Layout zerstört haben, jetzt fehlt mir die Zeit für das Suchfeld,
                                ich wollte auch noch die Tabellenköpfe generieren lassen und das n.g. bzw die bezeichnungen der werte (nicht der keys) in der liste anzeigen lassen
                                aber ich glaube es ist besser etwas halbfertiges abzugeben als etwas das gar nicht funktioniert-->

                            </div>
                </article>
            </main>
        </div>  
    </body>
</html>
